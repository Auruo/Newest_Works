package app;

import java.util.Scanner;

/*****
 *  Philip Squires
 *  ATM Simulator Version 3
 ******/

public class Main {

    public static void main(String[] args) {

        // initial balance and control variable
        double balance = 420.69;
        int transaction_type = 0;
        System.out.println("Welcome to America Bank, where your money belongs to us.");

        // (Gucci) Main Application Loop
        do {
            // print menu
            transaction_type = mainMenu();

            switch (transaction_type) {
                case 1:
                    // checks balance
                    printBalance(balance);
                    break;
                case 2:
                    // deposits then checks balance
                    balance = getDeposit(balance);
                    printBalance(balance);
                    break;
                case 3:
                    // withdrawal then check balance
                    balance = getWithdrawal(balance);
                    printBalance(balance);
                    break;
                case 4:
                    // quit
                    System.out.println("Goodbye.");
                    transaction_type = 4;
                    break;
                default:
                    // Invalid choice, try again
                    System.out.println("Invalid option selected. Please choose a valid option.");
            }

        } while (transaction_type != 4);
        // App ends here

    }

    // Gets deposit input from user, returns new balance
    private static double getDeposit(double balance) {

        // initialize scanner
        Scanner in = new Scanner(System.in);

        // ask for input
        System.out.print("Please enter the amount you would like to deposit: $");
        double deposit = in.nextDouble();

        // add amount from input to balance
        balance += deposit;

        // return balance
        return balance;
    }

    // withdrawals money from balance
    private static double getWithdrawal(double balance) {
        // initialize scanner
        Scanner in = new Scanner(System.in);

        // declare control and withdrawal amount variable
        boolean withdrawing = true;
        double withdrawal = 0.0;

        // while withdrawing (i.e. while withdrawal amount isn't covered by the balance) run this loop
        while (withdrawing) {
            // prompt for input
            System.out.print("Please enter the amount you would like to withdrawal: $");
            withdrawal = in.nextDouble();

            // if withdrawal is less than or equal to balance, withdrawal that amount
            if (withdrawal <= balance) {
                balance -= withdrawal;
                withdrawing = false;
            } else {
                // if withdrawal > balance, prompt for input after saying insufficient funds
                System.out.println("Insufficient funds.");
            }
        }
        // return balance to main method
        return balance;
    }

    // prints the current balance
    private static void printBalance(double balance) {
        System.out.printf("Your current balance is: %.2f", balance);
        System.out.println();
    }

    // prints the main menu and displays the options to choose from
    private static int mainMenu() {

        // initialize scanner and control variable
        int transaction_type = 0;
        Scanner in = new Scanner(System.in);

        System.out.println("***  MAIN MENU  ***");
        System.out.println("1. Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdrawal");
        System.out.println("4. Quit");
        System.out.println();

        // prompt for input
        System.out.print("Enter the number for your desired transaction: ");
        transaction_type = in.nextInt();

        // return control variable
        return transaction_type;
    }

}
