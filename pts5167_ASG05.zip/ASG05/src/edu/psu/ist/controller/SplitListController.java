package edu.psu.ist.controller;

import edu.psu.ist.model.ISplittableList;
import edu.psu.ist.view.SplitListView;

import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.NoSuchElementException;
// import java.util.Stack;

/**
 * The controller for the SplitList application.
 */
public class SplitListController {

    private ISplittableList<String> listModel;
    private SplitListView view;
    private String lastRemoved = "N/A";

    /**
     * @param m the model
     * @param v the view
     */
    public SplitListController(ISplittableList<String> m,
                               SplitListView v) {
        this.listModel = m;
        this.view = v;

        // set the initial text rendering the (empty) list
        updateListValueLabel();

        // add action listeners to the various buttons
        /**
         * @param e the event to be processed by the action listener
         */
        // Add to Right at Front button
        view.form.getAddToRightAtButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // get the text from the text field
                String itemToAdd = view.form.getItemToAddField().getText().trim();
                // if the text is empty, show an error dialog
                if (itemToAdd.isEmpty()) {
                    showErrorDialog("Item to add cannot be blank.");
                    return;
                }
                // add the item to the right list & update the value label
                listModel.addToRightAtFront(itemToAdd);
                updateListValueLabel();
            }
        });

        // Remove from Right at Front button
        view.form.getRemoveFromRightAtButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) throws NoSuchElementException {
                try {
                    // remove the item from the right list, update last removed, and update the value label
                    String removed = listModel.removeFromRightAtFront();
                    lastRemoved = removed;
                    updateListValueLabel();
                    // if right list is empty, show an error dialog
                } catch (NoSuchElementException ex) {
                    showErrorDialog("Cannot remove from empty right list.");
                }
            }
        });

        // Move Forward button
        view.form.getMoveForwardButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // move the item from the right list to the left list & update the value label
                    listModel.moveForward();
                    updateListValueLabel();
                    // if right list is empty, show an error dialog
                } catch (IllegalStateException ex) {
                    showErrorDialog("Cannot move forward, right list is empty.");
                }
            }
        });

        // Count of button
        view.form.getCountNumOfButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // get the text from the text field
                String itemToCount = view.form.getItemToAddField().getText().trim();
                // if the text is empty, show an error dialog
                if (itemToCount.isEmpty()) {
                    showErrorDialog("Item to count cannot be blank.");
                    return;
                }
                // count the item in the list & update the value label
                int count = listModel.countOf(itemToCount);
                String message = "The count of " + itemToCount + " is " + count + ".";
                JOptionPane.showMessageDialog(view, message);
            }
        });

        // Clear button
        view.form.getClearButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // clear the list & update the value label
                listModel.clear();
                updateListValueLabel();
            }
        });

        // Move to beginning button
        view.form.getMoveToBeginningButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // moves all items to the right list & update the value label
                listModel.moveToVeryBeginning();
                updateListValueLabel();
            }
        });
    }

    // updates all the value labels
    private void updateListValueLabel() {
        view.form.getListValueLabel().setText(listModel.toString());
        view.form.getLeftLenValue().setText(Integer.toString(listModel.leftLength()));
        view.form.getRightLenValue().setText(Integer.toString(listModel.rightLength()));
        view.form.getLastRemovedValue().setText(lastRemoved);
    }

    /**
     * @param message the error message to display
     * Shows an error dialog with the given message.
     */
    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(view, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}