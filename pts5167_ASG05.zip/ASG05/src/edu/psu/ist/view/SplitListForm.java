package edu.psu.ist.view;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class SplitListForm {
    private JPanel myPanel;
    private JLabel ListValueLabel;
    private JButton moveForwardButton;
    private JButton countNumOfButton;
    private JButton addToRightAtButton;
    private JButton removeFromRightAtButton;
    private JButton clearButton;
    private JButton moveToBeginningButton;
    private JTextField itemToAddField;
    private JLabel rightLenValue;
    private JLabel leftLenValue;
    private JLabel lastRemovedValue;
    private JLabel lastRemovedLabel;
    private JLabel leftLenLabel;
    private JLabel rightLenLabel;
    // private JButton undoButton;

    public JPanel getMyPanel() {
        return myPanel;
    }

    public JLabel getListValueLabel() {
        return ListValueLabel;
    }

    public JButton getMoveForwardButton() {
        return moveForwardButton;
    }

    public JButton getCountNumOfButton() {
        return countNumOfButton;
    }

    public JButton getAddToRightAtButton() {
        return addToRightAtButton;
    }

    public JButton getRemoveFromRightAtButton() {
        return removeFromRightAtButton;
    }

    public JButton getClearButton() {
        return clearButton;
    }

    public JButton getMoveToBeginningButton() {
        return moveToBeginningButton;
    }

    public JTextField getItemToAddField() {
        return itemToAddField;
    }

    public JLabel getRightLenValue() {
        return rightLenValue;
    }

    public JLabel getLeftLenValue() {
        return leftLenValue;
    }

    public JLabel getLastRemovedValue() {
        return lastRemovedValue;
    }

    /*public JButton getUndoButton() {
        return undoButton;
    }*/
}
