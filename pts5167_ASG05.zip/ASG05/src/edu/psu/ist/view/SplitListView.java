package edu.psu.ist.view;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class SplitListView extends JFrame {
    // uncomment this once the form is built (using the formbuilder) -- N
    // NOTE: assumes you name the form for your GUI: SplitListForm
    public final SplitListForm form;

    public SplitListView() {
        // uncomment the lines below once your form is built
        this.form = new SplitListForm();
        JPanel content = form.getMyPanel();
        this.setContentPane(content);

        // this.pack() was not automatically sizing properly, so I used setSize() instead
        this.setSize(400, 300);

        this.setTitle("Splittable Madness");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}