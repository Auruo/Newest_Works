package edu.psu.ist.model;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * @param <E> the type of elements in this list
 * Provides the implementation of the methods in the ISplittableList interface
 */
public class UtilListImpl<E> implements ISplittableList<E> {

    // Using LinkedLists for O(1) add and remove operations
    private LinkedList<E> left = new LinkedList<>();
    private LinkedList<E> right = new LinkedList<>();
    private Map<E, Integer> countingMap = new HashMap<>();

    /**
     * @param e the entry to add.
     * O(1)
     * Adds the entry (e) to the right list at the front of the list
     */
    @Override
    public void addToRightAtFront(E e) {
        right.addFirst(e);
        countingMap.put(e, countingMap.getOrDefault(e, 0) + 1);
    }

    /**
     * @return the removed entry
     * @throws NoSuchElementException if the right list is empty
     * O(1)
     * Removes the first entry in the right list
     */
    @Override
    public E removeFromRightAtFront() throws NoSuchElementException {
        // throw exception if right list is empty
        if (right.isEmpty()) {
            throw new NoSuchElementException("Cannot remove from empty right list.");
        }
        // remove the first entry in the right list
        E removed = right.removeFirst();
        // decrement the count of the removed entry in the counting map
        Integer count = countingMap.get(removed);
        // if the count is null or 1, remove the entry from the counting map, else decrement the count
        if (count != null && count > 1) {
            countingMap.put(removed, count - 1);
        } else {
            countingMap.remove(removed);
        }
        return removed;
    }

    /**
     * O(n)
     * Moves all entries from the left list and
     * sticks them to the front of the entries in the right list.
     */
    @Override
    public void moveToVeryBeginning() {
        // Add all elements from the left list to the front of the right list
        right.addAll(0, left);
        // Clear the counting map and re-populate it with all entries from the left list
        countingMap.clear();
        for (E e : left) {
            countingMap.put(e, countingMap.getOrDefault(e, 0) + 1);
        }
        // Clear the left list
        left.clear();
    }

    /**
     * @param e the entry to count
     * @return the number of occurrences of e in the list
     * O(n)
     * Counts the occurrences of e in both left and right lists
     */
    @Override
    public int countOf(E e) {
        int count = 0;
        // iterate through left list and count occurrences of e
        for (E item : left) {
            if (item.equals(e)) {
                count++;
            }
        }
        // iterate through right list and count occurrences of e
        for (E item : right) {
            if (item.equals(e)) {
                count++;
            }
        }
        return count;
    }

    /**
     * @throws IllegalStateException if the right list is empty
     * O(1)
     * Moves the first item in the right list to the end of the left list
     */
    @Override
    public void moveForward() throws IllegalStateException {
        // throw exception if right list is empty
        if (right.isEmpty()) {
            throw new IllegalStateException("No item to move forward in right list.");
        }
        // move the first item in the right list to the end of the left list
        left.addLast(right.removeFirst());
    }

    // O(1)
    // Returns the length of the left list
    @Override
    public int leftLength() {
        return left.size();
    }

    // O(1)
    // Returns the length of the right list
    @Override
    public int rightLength() {
        return right.size();
    }

    // O(n)
    // Clears all data structures
    @Override
    public void clear() {
        left.clear();
        right.clear();
        countingMap.clear();
    }

    // O(n)
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("<");
        boolean first = true;
        for (E e : left) {
            if (first) {
                sb.append(e);
                first = false;
            } else {
                sb.append(", ").append(e);
            }
        }
        sb.append("><");
        first = true;
        for (E e : right) {
            if (first) {
                sb.append(e);
                first = false;
            } else {
                sb.append(", ").append(e);
            }
        }
        return sb.append(">").toString();
    }
}